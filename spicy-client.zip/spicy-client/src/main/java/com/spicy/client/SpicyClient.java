package com.spicy.client;

import com.mojang.brigadier.Command;
import com.spicy.client.config.ConfigManager;
import com.spicy.client.gui.ClickGuiScreen;
import com.spicy.client.module.ModuleManager;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.minecraft.client.MinecraftClient;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class SpicyClient implements ClientModInitializer {
    public static final String MOD_ID = "spicyclient";
    public static final Logger LOGGER = LoggerFactory.getLogger("SpicyClient");

    public static ModuleManager modules;
    public static ConfigManager config;

    @Override
    public void onInitializeClient() {
        LOGGER.info("[Spicy Client] Bat dau khoi dong...");
        modules = new ModuleManager();
        modules.init();
        config = new ConfigManager(modules);
        config.init();

        ClientTickEvents.END_CLIENT_TICK.register(modules::tick);
        HudElementRegistry.addLast(Identifier.of(MOD_ID, "hud"),
                (ctx, tickCounter) -> modules.renderHud(ctx, MinecraftClient.getInstance()));
        ClientLifecycleEvents.CLIENT_STOPPING.register(c -> config.save());

        // Lenh /spicy: mo menu khong can phim (dung duoc ca tren dien thoai).
        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) ->
                dispatcher.register(ClientCommandManager.literal("spicy").executes(c -> {
                    MinecraftClient mc = c.getSource().getClient();
                    mc.send(() -> mc.setScreen(new ClickGuiScreen())); // tri hoan de khong bi dong cung o chat
                    return Command.SINGLE_SUCCESS;
                })));

        // Thong bao khi vao the gioi de xac nhan mod da duoc tai.
        ClientPlayConnectionEvents.JOIN.register((handler, sender, client) -> client.execute(() -> {
            if (client.player != null) {
                client.player.sendMessage(Text.literal(
                        "§d[Spicy Client]§r đã tải. Nhấn §eRight Shift§r hoặc gõ §e/spicy§r để mở menu."), false);
            }
        }));

        LOGGER.info("[Spicy Client] Da khoi dong xong, {} module. Phim mo menu: Right Shift, hoac lenh /spicy", modules.all().size());
    }
}
