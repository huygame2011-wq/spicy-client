package com.spicy.client.module.hud;

import com.spicy.client.module.Category;
import com.spicy.client.module.Module;
import com.spicy.client.setting.Setting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

/** Module HUD co vi tri, kich thuoc, mau chinh duoc. Lop con chi can ve noi dung. */
public abstract class HudModule extends Module {
    protected final Setting.Num x;
    protected final Setting.Num y;
    protected final Setting.Num scale = add(new Setting.Num("Scale", "Kích thước", 1.0, 0.5, 3.0));
    protected final Setting.Color color = add(new Setting.Color("Color", "Màu sắc", 0xFFC77DFF));

    protected HudModule(String name, String description, Category cat, int defX, int defY) {
        super(name, description, cat);
        this.x = add(new Setting.Num("X", "Vị trí ngang (X)", defX, 0, 1000));
        this.y = add(new Setting.Num("Y", "Vị trí dọc (Y)", defY, 0, 1000));
    }

    /** Ve noi dung tai goc (0,0); he thong tu dich chuyen + scale. */
    protected abstract void renderContent(DrawContext ctx, MinecraftClient mc);

    @Override
    public final void onHudRender(DrawContext ctx, MinecraftClient mc) {
        var m = ctx.getMatrices();
        m.pushMatrix();
        m.translate(x.f(), y.f());
        m.scale(scale.f(), scale.f());
        try {
            renderContent(ctx, mc);
        } finally {
            m.popMatrix();
        }
    }
}
