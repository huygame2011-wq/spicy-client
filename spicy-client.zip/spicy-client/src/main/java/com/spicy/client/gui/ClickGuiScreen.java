package com.spicy.client.gui;

import com.spicy.client.SpicyClient;
import com.spicy.client.config.ConfigManager;
import com.spicy.client.module.Category;
import com.spicy.client.module.Module;
import com.spicy.client.setting.Setting;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.client.input.KeyInput;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.*;
import java.util.function.DoubleConsumer;

/** Menu Spicy Client (tieng Viet). Mo bang Right Shift, dong bang Right Shift hoac Esc. */
public class ClickGuiScreen extends Screen {
    private static final int BG = 0xF0120A1E, SIDE = 0xFF0B0614, ACCENT = 0xFFA855F7, ACCENT_D = 0xFF6D28D9;
    private static final int TEXT = 0xFFEDE9FE, DIM = 0xFF9CA3AF, ROW = 0xFF1A1030, ROW_HOVER = 0xFF261650;
    private static final int OFF = 0xFF3B2F55, SUB = 0xFF150C26, WHITE = 0xFFFFFFFF;
    private static final int[] SWATCHES = {
            0xFFC77DFF, 0xFFFF6BD6, 0xFF60A5FA, 0xFF22D3EE, 0xFF4ADE80,
            0xFFFACC15, 0xFFFB923C, 0xFFF87171, 0xFFFFFFFF};
    private static final int CONFIG_TAB = Category.values().length;

    private static final class Hit {
        int x, y, w, h;
        Runnable click;
        DoubleConsumer drag;   // nhan ti le 0..1 (slider)
        boolean scrolled;      // nam trong vung cuon -> phai kiem tra clip
        boolean contains(double mx, double my) { return mx >= x && mx < x + w && my >= y && my < y + h; }
    }

    private final List<Hit> hits = new ArrayList<>();
    private final Set<Module> expanded = new HashSet<>();
    private int tab = Category.UTILITY.ordinal();
    private float scroll = 0, maxScroll = 0;
    private int clipTop, clipBottom;
    private Hit activeDrag;
    private String status = "";
    private TextFieldWidget searchField, configField;

    public ClickGuiScreen() { super(Text.literal("Spicy Client")); }

    @Override
    protected void init() {
        SpicyClient.config.save(); // dam bao profile hien tai co file
        searchField = new TextFieldWidget(textRenderer, 0, 0, 100, 14, Text.literal("Tìm"));
        searchField.setPlaceholder(Text.literal("Tìm module..."));
        searchField.setChangedListener(s -> scroll = 0);
        addDrawableChild(searchField);

        configField = new TextFieldWidget(textRenderer, 0, 0, 100, 14, Text.literal("Tên profile"));
        configField.setPlaceholder(Text.literal("Tên profile mới..."));
        configField.setMaxLength(24);
        addDrawableChild(configField);
    }

    @Override public boolean shouldPause() { return false; }
    @Override public void renderBackground(DrawContext ctx, int mx, int my, float delta) { /* tu ve nen */ }
    @Override public void removed() { SpicyClient.config.save(); }

    // ------------------------------------------------------------ ve
    @Override
    public void render(DrawContext ctx, int mx, int my, float delta) {
        hits.clear();
        ctx.fill(0, 0, width, height, 0xA0000000);

        int pw = Math.min(width - 16, 380), ph = Math.min(height - 16, 250);
        int px = (width - pw) / 2, py = (height - ph) / 2;
        int sideW = 100;

        ctx.fill(px - 1, py - 1, px + pw + 1, py + ph + 1, ACCENT_D);
        ctx.fill(px, py, px + pw, py + ph, BG);
        ctx.fillGradient(px, py, px + pw, py + 24, 0xFF4C1D95, 0xFF1A0B2E);
        ctx.fill(px, py + 24, px + pw, py + 25, ACCENT);
        ctx.drawTextWithShadow(textRenderer, "SPICY CLIENT", px + 8, py + 8, WHITE);

        searchField.setPosition(px + pw - 112, py + 5);
        searchField.setWidth(104);

        // thanh ben
        ctx.fill(px, py + 25, px + sideW, py + ph, SIDE);
        Category[] cats = Category.values();
        for (int i = 0; i <= CONFIG_TAB; i++) {
            int y = py + 32 + i * 22;
            boolean sel = i == tab;
            boolean over = mx >= px && mx < px + sideW && my >= y - 3 && my < y + 17;
            if (sel) ctx.fill(px, y - 3, px + sideW, y + 17, ROW_HOVER);
            else if (over) ctx.fill(px, y - 3, px + sideW, y + 17, ROW);
            if (sel) ctx.fill(px, y - 3, px + 2, y + 17, ACCENT);
            String label;
            String count = "";
            if (i < CONFIG_TAB) {
                label = cats[i].label;
                int n = 0;
                for (Module m : SpicyClient.modules.all()) if (m.getCategory() == cats[i]) n++;
                count = String.valueOf(n);
            } else {
                label = "Cấu hình";
            }
            int maxW = sideW - 28;
            ctx.drawTextWithShadow(textRenderer, textRenderer.trimToWidth(label, maxW), px + 8, y + 2, sel ? WHITE : TEXT);
            if (!count.isEmpty())
                ctx.drawTextWithShadow(textRenderer, count, px + sideW - 8 - textRenderer.getWidth(count), y + 2, DIM);
            final int idx = i;
            hit(px, y - 3, sideW, 20, false, () -> { tab = idx; scroll = 0; status = ""; });
        }
        ctx.drawTextWithShadow(textRenderer, "Right Shift: đóng", px + 8, py + ph - 12, DIM);

        int cx = px + sideW + 8, cy = py + 31, cw = pw - sideW - 16, ch = ph - 37;
        boolean cfg = tab == CONFIG_TAB && searchField.getText().isBlank();
        configField.setVisible(cfg);
        if (!cfg && configField.isFocused()) configField.setFocused(false);

        if (cfg) renderConfig(ctx, mx, my, cx, cy, cw, ch);
        else renderModules(ctx, mx, my, cx, cy, cw, ch);

        super.render(ctx, mx, my, delta); // ve o nhap lieu
    }

    private void renderModules(DrawContext ctx, int mx, int my, int cx, int cy, int cw, int ch) {
        String q = searchField.getText().trim().toLowerCase(Locale.ROOT);
        List<Module> list = new ArrayList<>();
        for (Module m : SpicyClient.modules.all()) {
            boolean ok = q.isEmpty()
                    ? m.getCategory().ordinal() == tab
                    : m.getName().toLowerCase(Locale.ROOT).contains(q)
                      || m.getDescription().toLowerCase(Locale.ROOT).contains(q);
            if (ok) list.add(m);
        }
        if (list.isEmpty()) {
            String t = q.isEmpty() ? "Chưa có module nào trong mục này." : "Không tìm thấy module phù hợp.";
            centered(ctx, t, cx, cw, cy + ch / 2 - 4, DIM);
            maxScroll = 0;
            return;
        }
        clipTop = cy;
        clipBottom = cy + ch;
        ctx.enableScissor(cx, cy, cx + cw, cy + ch);
        scroll = Math.max(0, Math.min(scroll, maxScroll));
        int y = cy - (int) scroll;
        int total = 0;
        for (Module m : list) {
            int rowH = 24;
            boolean on = m.isEnabled();
            boolean has = !m.getSettings().isEmpty();
            boolean open = expanded.contains(m);
            boolean over = mx >= cx && mx < cx + cw && my >= y && my < y + rowH && my >= cy && my < cy + ch;
            ctx.fill(cx, y, cx + cw, y + rowH - 2, over ? ROW_HOVER : ROW);
            if (on) ctx.fill(cx, y, cx + 2, y + rowH - 2, ACCENT);
            ctx.drawTextWithShadow(textRenderer, m.getName(), cx + 8, y + 3, on ? WHITE : TEXT);
            ctx.drawTextWithShadow(textRenderer, textRenderer.trimToWidth(m.getDescription(), cw - 70), cx + 8, y + 13, DIM);
            if (has) ctx.drawTextWithShadow(textRenderer, open ? "v" : ">", cx + cw - 44, y + 7, DIM);
            pill(ctx, cx + cw - 30, y + 7, on);
            hit(cx, y, cw - 48, rowH - 2, true, () -> { if (has) { if (!expanded.remove(m)) expanded.add(m); } });
            hit(cx + cw - 34, y, 34, rowH - 2, true, m::toggle);
            y += rowH;
            total += rowH;
            if (open) {
                for (Setting<?> s : m.getSettings()) {
                    int h = renderSetting(ctx, mx, my, s, cx + 8, y, cw - 8);
                    y += h;
                    total += h;
                }
                y += 3;
                total += 3;
            }
        }
        ctx.disableScissor();
        maxScroll = Math.max(0, total - ch);
        scroll = Math.max(0, Math.min(scroll, maxScroll));
    }

    private int renderSetting(DrawContext ctx, int mx, int my, Setting<?> s, int x, int y, int w) {
        if (s instanceof Setting.Bool b) {
            int h = 18;
            ctx.fill(x, y, x + w, y + h - 2, SUB);
            ctx.drawTextWithShadow(textRenderer, s.getLabel(), x + 6, y + 4, TEXT);
            pill(ctx, x + w - 28, y + 3, b.get());
            hit(x, y, w, h - 2, true, () -> b.set(!b.get()));
            return h;
        }
        if (s instanceof Setting.Num n) {
            int h = 28;
            ctx.fill(x, y, x + w, y + h - 2, SUB);
            boolean whole = n.max - n.min >= 20;
            String val = whole ? String.valueOf(n.get().intValue()) : String.format(Locale.ROOT, "%.2f", n.get());
            ctx.drawTextWithShadow(textRenderer, s.getLabel() + ": " + val, x + 6, y + 4, TEXT);
            int sx = x + 6, sw = w - 12, sy = y + 17;
            ctx.fill(sx, sy, sx + sw, sy + 4, OFF);
            int fw = (int) (sw * (n.get() - n.min) / (n.max - n.min));
            ctx.fill(sx, sy, sx + fw, sy + 4, ACCENT);
            ctx.fill(sx + fw - 2, sy - 2, sx + fw + 2, sy + 6, WHITE);
            Hit k = hit(sx - 2, sy - 4, sw + 4, 12, true, null);
            k.drag = f -> {
                double v = n.min + (n.max - n.min) * f;
                v = whole ? Math.round(v) : Math.round(v * 20) / 20.0;
                n.set(v);
            };
            return h;
        }
        if (s instanceof Setting.Color c) {
            int h = 30;
            ctx.fill(x, y, x + w, y + h - 2, SUB);
            ctx.drawTextWithShadow(textRenderer, s.getLabel(), x + 6, y + 4, TEXT);
            for (int i = 0; i < SWATCHES.length; i++) {
                int sx = x + 6 + i * 16, sy = y + 15;
                int col = SWATCHES[i];
                if (c.get() == col) ctx.fill(sx - 1, sy - 1, sx + 13, sy + 11, WHITE);
                ctx.fill(sx, sy, sx + 12, sy + 10, col);
                hit(sx, sy, 12, 10, true, () -> c.set(col));
            }
            return h;
        }
        return 0;
    }

    private void renderConfig(DrawContext ctx, int mx, int my, int cx, int cy, int cw, int ch) {
        String active = SpicyClient.config.getActive();
        ctx.drawTextWithShadow(textRenderer, "Profile đang dùng: " + active, cx, cy + 2, TEXT);

        int listTop = cy + 16, listBottom = cy + ch - 56;
        clipTop = listTop;
        clipBottom = listBottom;
        List<String> names = new ArrayList<>(SpicyClient.config.listProfiles());
        if (!names.contains(active)) names.add(0, active);
        Collections.sort(names);

        ctx.enableScissor(cx, listTop, cx + cw, listBottom);
        int y = listTop - (int) scroll, total = 0;
        for (String n : names) {
            boolean cur = n.equals(active);
            boolean over = mx >= cx && mx < cx + cw && my >= y && my < y + 18 && my >= listTop && my < listBottom;
            ctx.fill(cx, y, cx + cw, y + 18, over ? ROW_HOVER : ROW);
            if (cur) ctx.fill(cx, y, cx + 2, y + 18, ACCENT);
            ctx.drawTextWithShadow(textRenderer, n, cx + 8, y + 5, cur ? WHITE : TEXT);
            String tag = cur ? "Đang dùng" : "Bấm để chuyển";
            ctx.drawTextWithShadow(textRenderer, tag, cx + cw - 6 - textRenderer.getWidth(tag), y + 5, cur ? ACCENT : DIM);
            hit(cx, y, cw, 18, true, () -> {
                if (!cur) status = SpicyClient.config.switchProfile(n)
                        ? "Đã chuyển sang profile: " + n : "Không tìm thấy profile.";
            });
            y += 20;
            total += 20;
        }
        ctx.disableScissor();
        maxScroll = Math.max(0, total - (listBottom - listTop));
        scroll = Math.max(0, Math.min(scroll, maxScroll));

        if (!status.isEmpty())
            ctx.drawTextWithShadow(textRenderer, textRenderer.trimToWidth(status, cw), cx, cy + ch - 52, ACCENT);

        configField.setPosition(cx, cy + ch - 40);
        configField.setWidth(cw);

        int bw = (cw - 6) / 2, by = cy + ch - 20;
        button(ctx, mx, my, cx, by, bw, 16, "Tạo profile", () -> {
            String raw = configField.getText();
            if (SpicyClient.config.createProfile(raw)) {
                status = "Đã tạo profile: " + ConfigManager.sanitize(raw);
                configField.setText("");
            } else {
                status = "Tên không hợp lệ hoặc đã tồn tại.";
            }
        });
        button(ctx, mx, my, cx + bw + 6, by, bw, 16, "Lưu cấu hình", () -> {
            SpicyClient.config.save();
            status = "Đã lưu cấu hình.";
        });
    }

    // ------------------------------------------------------------ tien ich ve
    private void pill(DrawContext ctx, int x, int y, boolean on) {
        ctx.fill(x, y, x + 22, y + 10, on ? ACCENT : OFF);
        ctx.fill(on ? x + 12 : x + 2, y + 2, (on ? x + 12 : x + 2) + 8, y + 8, WHITE);
    }

    private void button(DrawContext ctx, int mx, int my, int x, int y, int w, int h, String label, Runnable r) {
        boolean over = mx >= x && mx < x + w && my >= y && my < y + h;
        ctx.fill(x, y, x + w, y + h, over ? ACCENT : ACCENT_D);
        ctx.drawTextWithShadow(textRenderer, label, x + (w - textRenderer.getWidth(label)) / 2, y + (h - 8) / 2, WHITE);
        hit(x, y, w, h, false, r);
    }

    private void centered(DrawContext ctx, String s, int x, int w, int y, int color) {
        ctx.drawTextWithShadow(textRenderer, s, x + (w - textRenderer.getWidth(s)) / 2, y, color);
    }

    private Hit hit(int x, int y, int w, int h, boolean scrolled, Runnable r) {
        Hit k = new Hit();
        k.x = x; k.y = y; k.w = w; k.h = h; k.scrolled = scrolled; k.click = r;
        hits.add(k);
        return k;
    }

    // ------------------------------------------------------------ nhap
    private void applyDrag(Hit k, double mx) {
        double f = (mx - (k.x + 2)) / (double) (k.w - 4);
        k.drag.accept(Math.max(0, Math.min(1, f)));
    }

    @Override
    public boolean mouseClicked(Click click, boolean doubled) {
        if (super.mouseClicked(click, doubled)) return true; // o nhap lieu
        if (click.button() != 0) return false;
        double mx = click.x(), my = click.y();
        for (int i = hits.size() - 1; i >= 0; i--) {
            Hit k = hits.get(i);
            if (!k.contains(mx, my)) continue;
            if (k.scrolled && (my < clipTop || my >= clipBottom)) continue;
            if (k.drag != null) { activeDrag = k; applyDrag(k, mx); }
            else if (k.click != null) k.click.run();
            return true;
        }
        return false;
    }

    @Override
    public boolean mouseDragged(Click click, double offsetX, double offsetY) {
        if (activeDrag != null) { applyDrag(activeDrag, click.x()); return true; }
        return super.mouseDragged(click, offsetX, offsetY);
    }

    @Override
    public boolean mouseReleased(Click click) {
        activeDrag = null;
        return super.mouseReleased(click);
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double h, double v) {
        scroll = Math.max(0, Math.min(maxScroll, scroll - (float) v * 16));
        return true;
    }

    @Override
    public boolean keyPressed(KeyInput input) {
        boolean typing = (searchField != null && searchField.isFocused())
                || (configField != null && configField.isFocused());
        if (input.key() == GLFW.GLFW_KEY_RIGHT_SHIFT && !typing) {
            close();
            return true;
        }
        return super.keyPressed(input);
    }
}
