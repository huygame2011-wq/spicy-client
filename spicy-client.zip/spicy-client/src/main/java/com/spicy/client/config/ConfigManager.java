package com.spicy.client.config;

import com.google.gson.*;
import com.spicy.client.SpicyClient;
import com.spicy.client.module.Module;
import com.spicy.client.module.ModuleManager;
import com.spicy.client.setting.Setting;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;

/** Luu/doc cau hinh theo profile: .minecraft/config/spicyclient/profiles/<ten>.json */
public final class ConfigManager {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private final Path dir = FabricLoader.getInstance().getConfigDir().resolve("spicyclient");
    private final Path profilesDir = dir.resolve("profiles");
    private final Path activeFile = dir.resolve("active.txt");
    private final ModuleManager modules;
    private String active = "default";

    public ConfigManager(ModuleManager modules) { this.modules = modules; }

    public String getActive() { return active; }

    public void init() {
        try {
            Files.createDirectories(profilesDir);
            if (Files.exists(activeFile)) {
                String s = sanitize(Files.readString(activeFile, StandardCharsets.UTF_8).trim());
                if (!s.isEmpty()) active = s;
            }
        } catch (IOException e) {
            SpicyClient.LOGGER.error("Khong tao duoc thu muc config", e);
        }
        load();
    }

    public static String sanitize(String name) { return name.replaceAll("[^A-Za-z0-9_-]", ""); }

    private Path file(String profile) { return profilesDir.resolve(profile + ".json"); }

    public void save() {
        JsonObject root = new JsonObject();
        JsonObject mods = new JsonObject();
        for (Module m : modules.all()) {
            JsonObject o = new JsonObject();
            o.addProperty("enabled", m.isEnabled());
            JsonObject s = new JsonObject();
            for (Setting<?> st : m.getSettings()) s.add(st.getName(), st.toJson());
            o.add("settings", s);
            mods.add(m.getId(), o);
        }
        root.add("modules", mods);
        try {
            Files.createDirectories(profilesDir);
            Files.writeString(file(active), GSON.toJson(root), StandardCharsets.UTF_8);
            Files.writeString(activeFile, active, StandardCharsets.UTF_8);
        } catch (IOException e) {
            SpicyClient.LOGGER.error("Luu config that bai", e);
        }
    }

    public void load() {
        Path f = file(active);
        if (!Files.exists(f)) return;
        try {
            JsonObject root = JsonParser.parseString(Files.readString(f, StandardCharsets.UTF_8)).getAsJsonObject();
            JsonObject mods = root.getAsJsonObject("modules");
            if (mods == null) return;
            for (Module m : modules.all()) {
                JsonObject o = mods.has(m.getId()) ? mods.getAsJsonObject(m.getId()) : null;
                if (o == null) continue;
                if (o.has("settings")) {
                    JsonObject s = o.getAsJsonObject("settings");
                    for (Setting<?> st : m.getSettings()) {
                        if (!s.has(st.getName())) continue;
                        try { st.fromJson(s.get(st.getName())); }
                        catch (RuntimeException ex) { SpicyClient.LOGGER.warn("Bo qua setting loi {}.{}", m.getName(), st.getName()); }
                    }
                }
                if (o.has("enabled")) m.setEnabled(o.get("enabled").getAsBoolean());
            }
        } catch (IOException | RuntimeException e) {
            SpicyClient.LOGGER.error("Doc profile '{}' that bai, dung mac dinh", active, e);
        }
    }

    public List<String> listProfiles() {
        List<String> out = new ArrayList<>();
        try (Stream<Path> s = Files.list(profilesDir)) {
            s.map(p -> p.getFileName().toString())
             .filter(n -> n.endsWith(".json"))
             .forEach(n -> out.add(n.substring(0, n.length() - 5)));
        } catch (IOException ignored) {}
        return out;
    }

    /** Tao profile moi tu cau hinh hien tai va chuyen sang no. */
    public boolean createProfile(String raw) {
        String name = sanitize(raw);
        if (name.isEmpty() || Files.exists(file(name))) return false;
        save();
        active = name;
        save();
        return true;
    }

    public boolean switchProfile(String raw) {
        String name = sanitize(raw);
        if (!Files.exists(file(name))) return false;
        save();
        active = name;
        for (Module m : modules.all()) {
            m.setEnabled(false);
            m.getSettings().forEach(Setting::reset);
        }
        load();
        save();
        return true;
    }
}
