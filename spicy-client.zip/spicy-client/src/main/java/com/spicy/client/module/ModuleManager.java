package com.spicy.client.module;

import com.spicy.client.SpicyClient;
import com.spicy.client.gui.ClickGuiScreen;
import com.spicy.client.module.hud.FpsHud;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;

import java.util.*;

public final class ModuleManager {
    /** Nhom phim tat trong Options > Controls. */
    private static final KeyBinding.Category KEY_CATEGORY =
            KeyBinding.Category.create(Identifier.of("spicyclient", "main"));

    /** Phim mo menu: mac dinh Right Shift, doi duoc trong Options > Controls. */
    private final KeyBinding openKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
            "Mở menu Spicy Client", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_RIGHT_SHIFT, KEY_CATEGORY));

    private final List<Module> modules = new ArrayList<>();
    private final Map<Module, KeyBinding> keys = new HashMap<>();

    public void init() {
        // Giai doan 2+ se them cac module khac tai day.
        register(new FpsHud());
    }

    private void register(Module m) {
        modules.add(m);
        // Moi module co 1 phim tat (mac dinh chua gan), doi trong Options > Controls.
        KeyBinding kb = new KeyBinding(
                "Bật/tắt " + m.getName(), InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_UNKNOWN, KEY_CATEGORY);
        keys.put(m, KeyBindingHelper.registerKeyBinding(kb));
    }

    public List<Module> all() { return Collections.unmodifiableList(modules); }

    public Optional<Module> byName(String name) {
        return modules.stream().filter(m -> m.getName().equalsIgnoreCase(name)).findFirst();
    }

    public void tick(MinecraftClient mc) {
        while (openKey.wasPressed()) {
            if (mc.currentScreen == null) mc.setScreen(new ClickGuiScreen());
        }
        for (Module m : modules) {
            KeyBinding kb = keys.get(m);
            while (kb != null && kb.wasPressed()) m.toggle();
            if (!m.isEnabled()) continue;
            try {
                m.onTick(mc);
            } catch (Throwable t) {
                SpicyClient.LOGGER.error("Module {} loi trong tick, tu dong tat", m.getName(), t);
                m.setEnabled(false);
            }
        }
    }

    public void renderHud(DrawContext ctx, MinecraftClient mc) {
        if (mc.options.hudHidden) return;
        for (Module m : modules) {
            if (!m.isEnabled()) continue;
            try {
                m.onHudRender(ctx, mc);
            } catch (Throwable t) {
                SpicyClient.LOGGER.error("Module {} loi khi ve HUD, tu dong tat", m.getName(), t);
                m.setEnabled(false);
            }
        }
    }
}
