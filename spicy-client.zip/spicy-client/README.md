# Spicy Client (Giai doan 1: nen tang)

Yeu cau: JDK 21, Gradle 9.x (hoac dung wrapper), Minecraft 1.21.11, Fabric Loader.

## Build
1. Mo https://fabricmc.net/develop, chon 1.21.11, copy dung so phien ban vao `gradle.properties`.
2. Tao wrapper (1 lan): `gradle wrapper --gradle-version 9.2.0`
3. Build: `./gradlew build` (Windows: `gradlew.bat build`)
4. JAR nam o `build/libs/spicy-client-0.1.0.jar` (khong lay file `-sources`).

## Cai dat
Cai Fabric Loader + Fabric API cho 1.21.11, copy JAR vao `.minecraft/mods`.

## Hien co (GD1)
- He thong Module (bat/tat an toan, setting, loi tu tat chu khong crash)
- Phim tat tung module: Options > Controls > "Spicy Client"
- Luu cau hinh + nhieu profile: `.minecraft/config/spicyclient/profiles/*.json`
- Module FPS (HUD, chinh X/Y/Scale/Color qua file profile den khi co ClickGUI o GD3)

## Giai doan 3 (ban dau): Menu tieng Viet
- Mo/dong menu: **Right Shift** (doi trong Options > Controls > "Spicy Client").
- Tim kiem module, bat/tat, bam vao module de mo cai dat (cong tac, thanh truot, bang mau).
- Tab "Cau hinh": xem/chuyen/tao profile, luu cau hinh.
- Luu y: chu co dau hien bang font du phong cua Minecraft nen hoi nhoe, day la binh thuong.

## Neu menu khong hien
1. Vao the gioi, neu thay dong chat "[Spicy Client] da tai..." thi mod DA chay.
2. Mo menu bang lenh `/spicy` (khong can phim). Neu OK, vao Options > Controls > "Spicy Client" kiem tra phim "Mo menu" co bi gan trung/doi khong.
3. Neu khong thay dong chat: mod chua duoc tai. Mo `.minecraft/logs/latest.log`, tim "Spicy" hoac "spicyclient" va gui cho nguoi ho tro.
